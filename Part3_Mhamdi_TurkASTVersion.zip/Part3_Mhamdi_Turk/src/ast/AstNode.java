package src.ast;

public abstract class AstNode {

}
