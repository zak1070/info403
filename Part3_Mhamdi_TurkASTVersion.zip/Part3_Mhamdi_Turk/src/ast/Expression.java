package src.ast;

public abstract class Expression extends AstNode {

}
