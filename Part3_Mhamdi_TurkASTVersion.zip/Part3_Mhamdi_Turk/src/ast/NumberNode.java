package src.ast;

public class NumberNode extends Expression {
public int value;

    public NumberNode(int value) {
        this.value = value;
    }
}
