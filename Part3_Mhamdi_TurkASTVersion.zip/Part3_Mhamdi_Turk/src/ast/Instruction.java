package src.ast;

public abstract class Instruction extends AstNode {

}
